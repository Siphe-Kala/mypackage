# mypackage
This library is an example of how to create a package

# How to install